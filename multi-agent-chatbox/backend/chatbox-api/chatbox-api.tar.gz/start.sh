#!/bin/bash
# Install poetry if not present
if ! command -v poetry &> /dev/null; then
    curl -sSL https://install.python-poetry.org | python3 -
fi
# Install dependencies
poetry install
# Start the application
poetry run uvicorn app.main:app --host 0.0.0.0 --port 80
